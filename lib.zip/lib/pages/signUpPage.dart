import 'package:flutter/material.dart';

class SignUpPage extends StatefulWidget {
  _SignUpPageState createState() => new _SignUpPageState();
}
class _SignUpPageState extends State<SignUpPage> {
  @override
  Widget build(BuildContext context) {
  
    return Center(
     child: Text('This is the Register Page')
    );
  } 

}